const express = require("express");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

app.use(express.json());


// Authentication Routes
const authRoutes = require("./routes/authRoutes");

app.use("/", authRoutes);


// Home Route
app.get("/", (req, res) => {
    res.json({
        message: "Student Portal API is running"
    });
});


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});